No installation is needed, 
 just unzip the files into some folder 
 (without blank space in path name please).

 